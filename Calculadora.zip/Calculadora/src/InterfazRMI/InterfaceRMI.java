/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InterfazRMI;

import java.rmi.Remote;
import java.rmi.RemoteException;
/**
 *
 * @author SAMUEL
 */
public interface InterfaceRMI extends Remote{
    public int suma(int x, int y) throws RemoteException;
    public int resta(int x, int y) throws RemoteException;
    public int multiplicacion(int x, int y) throws RemoteException;
    public int division(int x, int y) throws RemoteException;
}
