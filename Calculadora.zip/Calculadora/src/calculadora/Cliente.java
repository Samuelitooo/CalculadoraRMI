/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadora;


import InterfazRMI.InterfaceRMI;
import java.rmi.AccessException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Scanner;
/**
 *
 * @author SAMUEL
 */
public class Cliente extends javax.swing.JFrame{
    
    public static void main(String[] args) throws RemoteException, NotBoundException{
        Registry r = LocateRegistry.getRegistry("localhost",1099);
        InterfaceRMI i = (InterfaceRMI) r.lookup("CALCULADORA");
        Scanner teclado = new Scanner(System.in);
        int x,y;
        int menu;
        
        while(true){
            System.out.println("\n\nCalculadora\n"
                    + "1) Suma\n"
                    + "2) Resta\n"
                    + "3) Multiplicacion\n"
                    + "4) Division\n"
                    + "Cancel) Salir");
            System.out.println("Ingrese una opcion: ");
            menu = teclado.nextInt();
            
            System.out.println("Ingrese el primer numero: ");
            x = teclado.nextInt();
            System.out.println("Ingrese el segundo numero: ");
            y = teclado.nextInt();
            
            switch(menu){
                case 1:{
                    System.out.println("\n\nResultado de la suma: "+i.suma(x, y));
                    break;
                }
                case 2:{
                    System.out.println("\n\nResultado de la resta: "+i.resta(x, y));
                    break;
                }
                case 3:{
                    System.out.println("\n\nResultado de la multiplicacion: "+i.multiplicacion(x, y));
                    break;
                }
                case 4:{
                    System.out.println("\n\nResultado de la division: "+i.division(x, y));
                    break;
                }
            }
        }
    }
}
