/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadora;

import InterfazRMI.InterfaceRMI;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.ServerNotActiveException;
import java.rmi.server.UnicastRemoteObject;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author SAMUEL
 */
public class Servidor extends UnicastRemoteObject implements InterfaceRMI{
    public Servidor() throws RemoteException{
        super();
    }
    
    public static String operacion;
    
    public static void main(String[] args) throws RemoteException{
                try{
            Registry regis = LocateRegistry.createRegistry(1099);//nuevo registro
            regis.rebind("CALCULADORA", new Servidor());
            System.out.println("Servidor Encendido");
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }

    @Override
    public int suma(int x, int y) throws RemoteException {
        operacion = x + " + " + y;
        obtenerIP(x + y);
        return x + y;
    }

    @Override
    public int resta(int x, int y) throws RemoteException {
        operacion = x + " - " + y;
        obtenerIP(x - y);
        return x - y;
    }

    @Override
    public int multiplicacion(int x, int y) throws RemoteException {
        operacion = x + " * " + y;
        obtenerIP(x * y);
        return x * y;
    }

    @Override
    public int division(int x, int y) throws RemoteException {
        operacion = x + " / " + y;
        obtenerIP(x / y);
        return x / y;
    }
    
    private void obtenerIP(int resultado) throws UnsupportedOperationException{
        try{
            System.out.println(Servidor.getClientHost()+ " " + operacion + " = " + resultado);
        }catch(ServerNotActiveException e){
            Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, e);
        }
    }
}
